-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2022 at 03:50 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `brlicense_info`
--

CREATE TABLE `brlicense_info` (
  `name` text NOT NULL,
  `date1` date NOT NULL,
  `blood` varchar(25) NOT NULL,
  `father` text NOT NULL,
  `date2` date NOT NULL,
  `date3` date NOT NULL,
  `license` varchar(25) NOT NULL,
  `authority` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brlicense_info`
--

INSERT INTO `brlicense_info` (`name`, `date1`, `blood`, `father`, `date2`, `date3`, `license`, `authority`) VALUES
('Md Ashraful Hossain', '2022-11-24', '0', '', '2022-11-24', '0000-00-00', '0', 'authority'),
('আরমান হোসেন রানা', '2022-11-24', '0', '', '2022-11-24', '0000-00-00', '0', 'authority'),
('shamiurs', '2022-11-24', 'a+', '', '2022-11-24', '2022-11-24', '0', 'authority'),
('Shafin', '2022-11-24', 'O', '', '2022-11-24', '2022-11-24', '0', 'authority'),
('Shafin', '2022-11-24', 'O', '', '2022-11-24', '2022-11-24', '0', 'authority'),
('Shafin', '2022-11-24', 'O', '', '2022-11-24', '2022-11-24', '0', 'authority'),
('Shafin', '2022-11-24', 'O', '', '2022-11-24', '2022-11-24', '0', 'authority'),
('ffgg', '2022-11-24', 'O', '', '2022-11-24', '2022-11-24', '0', 'authority'),
('MD HRIDIY', '2022-11-24', 'b', '', '2022-11-24', '2022-11-24', '137', 'BRTA'),
('Md Ashraful Hossain', '2022-11-24', 'A+', '', '2022-11-24', '2022-11-24', '18192103137', 'BRTA'),
('', '2022-11-27', '', '', '2022-11-27', '2022-11-27', '', ''),
('', '2022-11-27', '', '', '2022-11-27', '2022-11-27', '', ''),
('Md Ashraful Hossain', '2022-11-27', 'a+', '', '2022-11-27', '2022-11-27', '18192103199', 'BRTA');

-- --------------------------------------------------------

--
-- Table structure for table `nid_info`
--

CREATE TABLE `nid_info` (
  `name1` varchar(25) DEFAULT NULL,
  `name2` varchar(25) DEFAULT NULL,
  `father` varchar(25) NOT NULL,
  `mother` varchar(25) NOT NULL,
  `date` date NOT NULL,
  `blood` varchar(20) NOT NULL,
  `nid` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nid_info`
--

INSERT INTO `nid_info` (`name1`, `name2`, `father`, `mother`, `date`, `blood`, `nid`) VALUES
('rrrr', 'rrrr', 'tttt', 'tttt', '0000-00-00', 'AB+', '1111111333333'),
('GGWPASHRAFUL', 'মোঃ আশরাফুল হোসেন', 'মোঃ এ আজিজ', 'সেলিনা আক্তার', '2022-11-01', 'A+', '1125452022'),
('Md. Ashraful Hossain', 'মোঃ আশরাফুল হোসেন', 'addul aziz', 'salina akter', '2000-09-01', 'A+', '15'),
('Mahmudul Hasan', 'মাহমুদুল হাসান', 'মোশারফ হোসেন', 'মাহফুজা বেগম', '2021-05-30', 'AB+', '18192103139'),
('Rigoberto Gerlach', 'রবার্ট', 'রবার্ট সিনিয়র', 'জুলি', '1944-01-01', 'A+', '1971'),
('মোঃ আশরাফুল হোসেন', 'মোঃ আশরাফুল হোসেন', 'পিতা', 'পিতা', '2022-11-26', 'A+', '2018'),
('মোঃ আশরাফুল হোসেন', 'মোঃ আশরাফুল হোসেন', 'fathertest', 'mothertest', '2022-11-26', 'A+', '2022'),
('Rigoberto Gerlach', 'Rigoberto Gerlach', 'মোঃ এ আজিজ', 'সেলিনা আক্তার', '2022-11-30', 'O+', '8999');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `nid_info`
--
ALTER TABLE `nid_info`
  ADD PRIMARY KEY (`nid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
